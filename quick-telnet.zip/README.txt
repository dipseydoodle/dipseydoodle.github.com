Readme.

To use: 

1. Unzip the file you've downloaded.

2. cd to the file or directory (i.e. cd Users/Me/Applications/) or, on Mac; copy paste the folder name in a terminal preceded by cd.

2 chmod 755 quick-telnet.bash (I already did this but you may have to as-well.)

3 bash quick-telnet.bash

---

On Mac OS X you can make the file executable by renaming the file a .command and chomping it.

---

Using Telnet.

1. On the prompt, enter an adress (i.e. example.example.com)

2. On the prompt, enter a port number.

3. Enjoy. This should run on any Macintosh,BSD,Linux,*nix etc.

Thanks for downloading,

dipseydoodle.